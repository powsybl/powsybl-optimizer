/**
 * Copyright (c) 2022,2023 RTE (http://www.rte-france.com), Coreso and TSCNet Services
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */
package main.java.com.powsybl.stateestimator.parameters.input.knowledge;

import com.powsybl.iidm.network.Identifiable;
import com.powsybl.iidm.network.Network;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Pierre ARVY <pierre.arvy@artelys.com>
 * @author Lucas RIOU <lucas.riou@artelys.com>
 */
public class StateEstimatorKnowledge {

    public static final String DEFAULT_SLACK_SELECTION_MODE = "MOST_MESHED";
    Map<Integer, ArrayList<String>> activePowerFlowMeasures = new HashMap<>();
    Map<Integer, ArrayList<String>> reactivePowerFlowMeasures = new HashMap<>();

    Map<Integer, ArrayList<String>> activePowerInjectedMeasures = new HashMap<>();

    Map<Integer, ArrayList<String>> reactivePowerInjectedMeasures = new HashMap<>();

    Map<Integer, ArrayList<String>> voltageMagnitudeMeasures = new HashMap<>();

    Map<Integer, String> suspectBranches = new HashMap<>();

    String slackBus;

    public StateEstimatorKnowledge(Network network) {
        setSlack(DEFAULT_SLACK_SELECTION_MODE, network);
    }


    public Map<Integer, ArrayList<String>> getActivePowerFlowMeasures() {
        return activePowerFlowMeasures;
    }

    public Map<Integer, ArrayList<String>> getReactivePowerFlowMeasures() {
        return reactivePowerFlowMeasures;
    }

    public Map<Integer, ArrayList<String>> getActivePowerInjectedMeasures() {
        return activePowerInjectedMeasures;
    }

    public Map<Integer, ArrayList<String>> getReactivePowerInjectedMeasures() {
        return reactivePowerInjectedMeasures;
    }

    public Map<Integer, ArrayList<String>> getVoltageMagnitudeMeasures() {
        return voltageMagnitudeMeasures;
    }

    public Map<Integer, String> getSuspectBranches() {
        return suspectBranches;
    }

    public String getSlackBus() {
        return slackBus;
    }

    /**
     * @param measurementNumber The number of the measurement for this type
     * @param measure           The active power flow measure to be added (contains location, value and variance)
     * @param network           The network to which the measurement is related
     * @return The object on which the method is applied
     */
    public StateEstimatorKnowledge addActivePowerFlowMeasure(Integer measurementNumber, Map<String, String> measure, Network network) {
        // Consistency checks on the measurement provided
        if (measurementNumber < 1) {
            throw new IllegalArgumentException("The measurement number must be a nonzero integer.");
        }
        if (activePowerFlowMeasures.containsKey(measurementNumber)) {
            throw new IllegalArgumentException("The measurement number must be unique within the set of active power flow measurements.");
        }
        if (!measure.containsKey("Value")) {
            throw new IllegalArgumentException("No entry corresponding to the measurement value (recall : in MW).");
        }
        if (!measure.containsKey("Variance")) {
            throw new IllegalArgumentException("No entry corresponding to the measurement variance (recall : in MW^2).");
        }
        if (!measure.containsKey("BranchID")) {
            throw new IllegalArgumentException("No entry corresponding to the branch ID related to the measurement.");
        }
        if (!measure.containsKey("FirstBusID")) {
            throw new IllegalArgumentException("No entry corresponding to the ID of the first bus related to the measurement.");
        }
        if (!measure.containsKey("SecondBusID")) {
            throw new IllegalArgumentException("No entry corresponding to the ID of the second bus related to the measurement.");
        }
        if (!measure.containsKey("Type")) {
            throw new IllegalArgumentException("No entry corresponding to the type of the measurement.");
        }
        if (measure.size() != 6) {
            throw new IllegalArgumentException("Unexpected number of indications given relative to the measurement.");
        }
        // Check that IDs related to the measurement exist in the network
        if (!network.getBranchStream().map(Identifiable::getId).toList().contains(measure.get("BranchID"))) {
            throw new IllegalArgumentException("The branch ID related to the measurement does not exist in the network.");
        }
        if (!network.getBusView().getBusStream().map(Identifiable::getId).toList().contains(measure.get("FirstBusID"))) {
            throw new IllegalArgumentException("The ID of the first bus related to the measurement does not exist in the network.");
        }
        if (!network.getBusView().getBusStream().map(Identifiable::getId).toList().contains(measure.get("SecondBusID"))) {
            throw new IllegalArgumentException("The ID of the second bus related to the measurement does not exist in the network.");
        }
        // Add the measurement to the list
        ArrayList<String> arrayMeasure = new ArrayList<>();
        arrayMeasure.add(measure.get("Type"));
        arrayMeasure.add(measure.get("BranchID"));
        arrayMeasure.add(measure.get("FirstBusID"));
        arrayMeasure.add(measure.get("SecondBusID"));
        arrayMeasure.add(measure.get("Value"));
        arrayMeasure.add(measure.get("Variance"));
        activePowerFlowMeasures.put(measurementNumber, arrayMeasure);
        return this;
    }

    /**
     * @param measurementNumber The number of the measurement for this type
     * @param measure           The reactive power flow measure to be added (contains location, value and variance)
     * @param network           The network to which the measurement is related
     * @return The object on which the method is applied.
     */
    public StateEstimatorKnowledge addReactivePowerFlowMeasure(Integer measurementNumber, Map<String, String> measure, Network network) {
        // Consistency checks on the measurement provided
        if (measurementNumber < 1) {
            throw new IllegalArgumentException("The measurement number must be a nonzero integer.");
        }
        if (reactivePowerFlowMeasures.containsKey(measurementNumber)) {
            throw new IllegalArgumentException("The measurement number must be unique within the set of reactive power flow measurements.");
        }
        if (!measure.containsKey("Value")) {
            throw new IllegalArgumentException("No entry corresponding to the measurement value (recall : in MVar).");
        }
        if (!measure.containsKey("Variance")) {
            throw new IllegalArgumentException("No entry corresponding to the measurement variance (recall : in MVar^2).");
        }
        if (!measure.containsKey("BranchID")) {
            throw new IllegalArgumentException("No entry corresponding to the branch ID related to the measurement.");
        }
        if (!measure.containsKey("FirstBusID")) {
            throw new IllegalArgumentException("No entry corresponding to the ID of the first bus related to the measurement.");
        }
        if (!measure.containsKey("SecondBusID")) {
            throw new IllegalArgumentException("No entry corresponding to the ID of the second bus related to the measurement.");
        }
        if (!measure.containsKey("Type")) {
            throw new IllegalArgumentException("No entry corresponding to the type of the measurement.");
        }
        if (measure.size() != 6) {
            throw new IllegalArgumentException("Unexpected number of indications given relative to the measurement.");
        }
        // Check that IDs related to the measurement exist in the network
        if (!network.getBranchStream().map(Identifiable::getId).toList().contains(measure.get("BranchID"))) {
            throw new IllegalArgumentException("The branch ID related to the measurement does not exist in the network.");
        }
        if (!network.getBusView().getBusStream().map(Identifiable::getId).toList().contains(measure.get("FirstBusID"))) {
            throw new IllegalArgumentException("The ID of the first bus related to the measurement does not exist in the network.");
        }
        if (!network.getBusView().getBusStream().map(Identifiable::getId).toList().contains(measure.get("SecondBusID"))) {
            throw new IllegalArgumentException("The ID of the second bus related to the measurement does not exist in the network.");
        }
        // Add the measurement to the list
        ArrayList<String> arrayMeasure = new ArrayList<>();
        arrayMeasure.add(measure.get("Type"));
        arrayMeasure.add(measure.get("BranchID"));
        arrayMeasure.add(measure.get("FirstBusID"));
        arrayMeasure.add(measure.get("SecondBusID"));
        arrayMeasure.add(measure.get("Value"));
        arrayMeasure.add(measure.get("Variance"));
        reactivePowerFlowMeasures.put(measurementNumber, arrayMeasure);
        return this;
    }

    /**
     * @param measurementNumber The number of the measurement for this type
     * @param measure           The active injected power measure to be added (contains location, value and variance)
     * @param network           The network to which the measurement is related
     * @return The object on which the method is applied.
     */
    public StateEstimatorKnowledge addActivePowerInjectedMeasure(Integer measurementNumber, Map<String, String> measure, Network network) {
        // Consistency checks on the measurement provided
        if (measurementNumber < 1) {
            throw new IllegalArgumentException("The measurement number must be a nonzero integer.");
        }
        if (activePowerInjectedMeasures.containsKey(measurementNumber)) {
            throw new IllegalArgumentException("The measurement number must be unique within the set of active injected power measurements.");
        }
        if (!measure.containsKey("Value")) {
            throw new IllegalArgumentException("No entry corresponding to the measurement value (recall : in MW).");
        }
        if (!measure.containsKey("Variance")) {
            throw new IllegalArgumentException("No entry corresponding to the measurement variance (recall : in MW^2).");
        }
        if (!measure.containsKey("BusID")) {
            throw new IllegalArgumentException("No entry corresponding to the ID of the bus related to the measurement.");
        }
        if (!measure.containsKey("Type")) {
            throw new IllegalArgumentException("No entry corresponding to the type of the measurement.");
        }
        if (measure.size() != 4) {
            throw new IllegalArgumentException("Unexpected number of indications given relative to the measurement.");
        }
        // Check that ID related to the measurement exist in the network
        if (!network.getBusView().getBusStream().map(Identifiable::getId).toList().contains(measure.get("BusID"))) {
            throw new IllegalArgumentException("The ID of the bus related to the measurement does not exist in the network.");
        }
        // Add the measurement to the list
        ArrayList<String> arrayMeasure = new ArrayList<>();
        arrayMeasure.add(measure.get("Type"));
        arrayMeasure.add(measure.get("BusID"));
        arrayMeasure.add(measure.get("Value"));
        arrayMeasure.add(measure.get("Variance"));
        activePowerInjectedMeasures.put(measurementNumber, arrayMeasure);
        return this;
    }

    /**
     * @param measurementNumber The number of the measurement for this type
     * @param measure           The reactive injected power measure to be added (contains location, value and variance)
     * @param network           The network to which the measurement is related
     * @return The object on which the method is applied.
     */
    public StateEstimatorKnowledge addReactivePowerInjectedMeasure(Integer measurementNumber, Map<String, String> measure, Network network) {
        // Consistency checks on the measurement provided
        if (measurementNumber < 1) {
            throw new IllegalArgumentException("The measurement number must be a nonzero integer.");
        }
        if (reactivePowerInjectedMeasures.containsKey(measurementNumber)) {
            throw new IllegalArgumentException("The measurement number must be unique within the set of reactive injected power measurements.");
        }
        if (!measure.containsKey("Value")) {
            throw new IllegalArgumentException("No entry corresponding to the measurement value (recall : in MVar).");
        }
        if (!measure.containsKey("Variance")) {
            throw new IllegalArgumentException("No entry corresponding to the measurement variance (recall : in MVar^2).");
        }
        if (!measure.containsKey("BusID")) {
            throw new IllegalArgumentException("No entry corresponding to the ID of the bus related to the measurement.");
        }
        if (!measure.containsKey("Type")) {
            throw new IllegalArgumentException("No entry corresponding to the type of the measurement.");
        }
        if (measure.size() != 4) {
            throw new IllegalArgumentException("Unexpected number of indications given relative to the measurement.");
        }
        // Check that ID related to the measurement exist in the network
        if (!network.getBusView().getBusStream().map(Identifiable::getId).toList().contains(measure.get("BusID"))) {
            throw new IllegalArgumentException("The ID of the bus related to the measurement does not exist in the network.");
        }
        // Add the measurement to the list
        ArrayList<String> arrayMeasure = new ArrayList<>();
        arrayMeasure.add(measure.get("Type"));
        arrayMeasure.add(measure.get("BusID"));
        arrayMeasure.add(measure.get("Value"));
        arrayMeasure.add(measure.get("Variance"));
        reactivePowerInjectedMeasures.put(measurementNumber, arrayMeasure);
        return this;
    }

    /**
     * @param measurementNumber The number of the measurement for this type
     * @param measure           The voltage magnitude measure to be added (contains location, value and variance)
     * @param network           The network to which the measurement is related
     * @return The object on which the method is applied.
     */
    public StateEstimatorKnowledge addVoltageMagnitudeMeasure(Integer measurementNumber, Map<String, String> measure, Network network) {
        // Consistency checks on the measurement provided
        if (measurementNumber < 1) {
            throw new IllegalArgumentException("The measurement number must be a nonzero integer.");
        }
        if (voltageMagnitudeMeasures.containsKey(measurementNumber)) {
            throw new IllegalArgumentException("The measurement number must be unique within the set of voltage magnitude measurements.");
        }
        if (!measure.containsKey("Value")) {
            throw new IllegalArgumentException("No entry corresponding to the measurement value (recall : in kV).");
        }
        if (Float.parseFloat(measure.get("Value")) < 0) {
            throw new IllegalArgumentException(("The value of a measurement on voltage magnitude must be non-negative."));
        }
        if (!measure.containsKey("Variance")) {
            throw new IllegalArgumentException("No entry corresponding to the measurement variance (recall : in kV^2).");
        }
        if (!measure.containsKey("BusID")) {
            throw new IllegalArgumentException("No entry corresponding to the ID of the bus related to the measurement.");
        }
        if (!measure.containsKey("Type")) {
            throw new IllegalArgumentException("No entry corresponding to the type of the measurement.");
        }
        if (measure.size() != 4) {
            throw new IllegalArgumentException("Unexpected number of indications given relative to the measurement.");
        }
        // Check that ID related to the measurement exist in the network
        if (!network.getBusView().getBusStream().map(Identifiable::getId).toList().contains(measure.get("BusID"))) {
            throw new IllegalArgumentException("The ID of the bus related to the measurement does not exist in the network.");
        }
        // Add the measurement to the list
        ArrayList<String> arrayMeasure = new ArrayList<>();
        arrayMeasure.add(measure.get("Type"));
        arrayMeasure.add(measure.get("BusID"));
        arrayMeasure.add(measure.get("Value"));
        arrayMeasure.add(measure.get("Variance"));
        voltageMagnitudeMeasures.put(measurementNumber, arrayMeasure);
        return this;
    }

    /**
     * @param suspectBranchNumber The number corresponding to the addition of new suspect branch
     * @param suspectBranchId     The ID of the suspect branch added, within the network
     * @param network             The network to which the measurement is related
     * @return The object on which the method is applied.
     */
    public StateEstimatorKnowledge addSuspectBranch(Integer suspectBranchNumber, String suspectBranchId, Network network) {
        // Consistency checks
        if (suspectBranchNumber < 1) {
            throw new IllegalArgumentException("The suspect branch number must be a nonzero integer.");
        }
        if (suspectBranches.containsKey(suspectBranchNumber)) {
            throw new IllegalArgumentException("The suspect branch number must be unique within the set of suspect branches.");
        }
        if (suspectBranches.containsValue(suspectBranchId)) {
            throw new IllegalArgumentException("This suspect branch has already been added.");
        }
        // Check that the ID of the suspect branch exists in the network
        if (!network.getBranchStream().map(Identifiable::getId).toList().contains(suspectBranchId)) {
            throw new IllegalArgumentException("The ID of the suspect branch does not exist in the network.");
        }
        suspectBranches.put(suspectBranchNumber, suspectBranchId);
        return this;
    }

    /**
     * @param slackBusId The ID of the bus chosen as angle reference ("slack"). Can be equal to "MOST_MESHED" if such selection method is chosen.
     * @param network    The network to which the measurement is related.
     */
    public void setSlack(String slackBusId, Network network) {
        if (slackBusId.equals(DEFAULT_SLACK_SELECTION_MODE)) {
            slackBus = selectMostMeshedBus(network);
        }
        // If slack bus ID is directly given, check that its ID does exist in the network
        else if (!network.getBusView().getBusStream().map(Identifiable::getId).toList().contains(slackBusId)) {
            throw new IllegalArgumentException("The ID of the bus indicated as slack does not exist in the network.");
        } else {
            slackBus = slackBusId;
        }
    }

    public static String selectMostMeshedBus(Network network) {
        // Map each bus of the network to its nominal voltage
        Map<String, Double> nominalVoltages = network.getBusView().getBusStream().collect(Collectors.toMap(Identifiable::getId, bus -> bus.getVoltageLevel().getNominalV()));
        // Find the maximum nominal voltage in the network
        Double maxNominalV = nominalVoltages.entrySet().stream().max(Map.Entry.comparingByValue()).get().getValue();
        String slackBusId = network.getBusView().getBuses().iterator().next().getId();
        int largestNbBranchesConnected = 0;
        // Keep in memory the most connected bus with nominal voltage at least larger than 90% of the maximum nominal voltage
        for (Map.Entry<String, Double> entry : nominalVoltages.entrySet()) {
            String busId = entry.getKey();
            Double busNominalV = entry.getValue();
            if (busNominalV > 0.9 * maxNominalV) {
                if (network.getBusView().getBus(busId).getConnectedTerminalCount() > largestNbBranchesConnected) {
                    slackBusId = busId;
                }
            }
        }
        return slackBusId;
    }
}
