/**
 * Copyright (c) 2022,2023 RTE (http://www.rte-france.com), Coreso and TSCNet Services
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */
package test.java.com.powsybl.stateestimator;

import com.powsybl.computation.local.LocalComputationManager;
import com.powsybl.divergenceanalyser.parameters.input.DivergenceAnalyserParameters;
import com.powsybl.iidm.network.Network;
import com.powsybl.loadflow.LoadFlow;
import com.powsybl.loadflow.LoadFlowParameters;
import com.powsybl.loadflow.LoadFlowResult;
import com.powsybl.openloadflow.OpenLoadFlowParameters;
import main.java.com.powsybl.stateestimator.StateEstimator;
import main.java.com.powsybl.stateestimator.StateEstimatorConfig;
import main.java.com.powsybl.stateestimator.StateEstimatorResults;
import main.java.com.powsybl.stateestimator.parameters.input.knowledge.StateEstimatorKnowledge;
import main.java.com.powsybl.stateestimator.parameters.input.options.StateEstimatorOptions;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * @author Pierre ARVY <pierre.arvy@artelys.com>
 * @author Lucas RIOU <lucas.riou@artelys.com>
 */
public class UseExample {

    void useExample() throws IOException {

        // Load your favorite network (IIDM format preferred)
        Network network = Network.read("your favorite network");

        // Load Flow parameters
        LoadFlowParameters parametersLf = new LoadFlowParameters();
        OpenLoadFlowParameters parametersExt = OpenLoadFlowParameters.create(parametersLf);
        parametersExt.setAlwaysUpdateNetwork(true);

        // Solve the Load Flow problem for the network and generate "measurements" from the results
        LoadFlowResult loadFlowResult = LoadFlow.run(network, parametersLf);
        assertTrue(loadFlowResult.isFullyConverged());
        StateEstimatorKnowledge knowledge = new StateEstimatorKnowledge(network);
        // TODO
        knowledge.generateRandomMeasurements();

        // Defines the options for the state estimation
        StateEstimatorOptions options = new StateEstimatorOptions();
        options.setResolutionNlp().setMaxTimeSolving(30);

        // Run the state estimation and print the results
        StateEstimatorResults results = StateEstimator.runStateEstimation(network, network.getVariantManager().getWorkingVariantId(),
                knowledge, options, new StateEstimatorConfig(true), new LocalComputationManager());
        results.printAllResultsPu();
    }
}
